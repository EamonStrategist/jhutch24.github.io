"use strict";
/*    JavaScript 7th Edition
      Chapter 5
      Chapter Case

      Application to generate a slide show
      Author: 
      Date:   

      Filename: js05.js
*/

window.addEventListener("load", setupGallery);

function setupGallery() {
   let imageCount = imgFiles.length;
   let galleryBox = document.getElementById("lightbox");
   let favoritesBox = document.getElementById("favorites");
   let currentSlide = 1;
   let runShow = true;
   let showRunning;
   let tempImages = [];


   let galleryTitle = document.createElement("h1");
   galleryTitle.id = "galleryTitle";
   let slidesTitle = lightboxTitle; // TODO figure out title
   galleryTitle.textContent = slidesTitle;
   galleryBox.appendChild(galleryTitle);

   let slideCounter = document.createElement("div");
   slideCounter.id = "slideCounter";
   slideCounter.textContent = currentSlide + "/" + imageCount;
   galleryBox.appendChild(slideCounter);

   let leftBox = document.createElement("div");
   leftBox.id = "leftBox";
   leftBox.innerHTML = "&#9664;";
   leftBox.onclick = moveToLeft;
   galleryBox.appendChild(leftBox);

   let rightBox = document.createElement("div");
   rightBox.id = "rightBox";
   rightBox.innerHTML = "&#9654;";
   rightBox.onclick = moveToRight;
   galleryBox.appendChild(rightBox);

   let playPause = document.createElement("div");
   playPause.id = "playPause";
   let playPauseHat = document.createElement("img");
   playPauseHat.src = "cowboy_hat.jpg";
   playPauseHat.alt = "";
   let toggle = false;
   playPauseHat.onclick = function() {if(!toggle){playPauseHat.src = "cowboy_hat_pressed.jpg"; toggle = true;}else{playPauseHat.src = "cowboy_hat.jpg"; toggle= false;}};
   playPause.append(playPauseHat);
   playPause.onclick = startStopShow;
   galleryBox.appendChild(playPause);

   let slideBox = document.createElement("div");
   slideBox.id = "slideBox";
   galleryBox.appendChild(slideBox);


   for (let i = 0; i < imageCount; i++) {
      let image = document.createElement("img");
      image.src = imgFiles[i];
      image.alt = imgCaptions[i];
      image.onclick = createModal;
      slideBox.appendChild(image);
   }




   function moveToRight() {
      let firstImage = slideBox.firstElementChild.cloneNode("true");
      firstImage.onclick = createModal;
      slideBox.appendChild(firstImage);
      slideBox.removeChild(slideBox.firstElementChild);
      currentSlide++;
      if (currentSlide > imageCount) {
         currentSlide = 1;
      }
      slideCounter.textContent = currentSlide + " / " + imageCount;
   }

   function moveToLeft() {
      let lastImage = slideBox.lastElementChild.cloneNode("true");
      lastImage.onclick = createModal;
      slideBox.removeChild(slideBox.lastElementChild);
      slideBox.insertBefore(lastImage, slideBox.firstElementChild);
      currentSlide--;
      if (currentSlide === 0) {
         currentSlide = imageCount;
      }
      slideCounter.textContent = currentSlide + " / " + imageCount;
   }

   function startStopShow() {
      if (runShow) {
         showRunning = window.setInterval(moveToRight, 2000);
         runShow = false;
      } else {
         window.clearInterval(showRunning);
         runShow = true;
      }
   }

   function createModal() {
      let modalWindow = document.createElement("div");
      modalWindow.id = "lbOverlay";
      let figureBox = document.createElement("figure");
      modalWindow.appendChild(figureBox);

      let modalImage = this.cloneNode("true");
      figureBox.appendChild(modalImage);

      let figureCaption = document.createElement("figcaption");
      figureCaption.textContent = modalImage.alt;
      figureBox.appendChild(figureCaption);

      let closeBox = document.createElement("div");
      closeBox.id = "lbOverlayClose";
      closeBox.innerHTML = "&times;";
      closeBox.onclick = function () {
         document.body.removeChild(modalWindow);
      }

      modalWindow.appendChild(closeBox);


      let modalButtonDiv = document.createElement("div");
      modalButtonDiv.id = "lbButtonDiv";
      modalWindow.appendChild(modalButtonDiv);
      let modalButton = document.createElement("button");
      modalButton.id = "lbButton";
      modalButton.textContent = "Add to Favorites";
      modalButtonDiv.appendChild(modalButton);


      document.body.appendChild(modalWindow);


      modalButton.onclick = function () {

         
         if (tempImages.length < 5) {

            if (tempImages.length > 0) {
               
               let copy = false;
               for (let i = 0; i < tempImages.length; i++) {
                  if (tempImages[i].src == modalImage.src) {
                     copy = true
                  }
               }

               if (copy == false) {
                  tempImages.push(modalImage.cloneNode(true));
                  createFavorites();
               }

               copy = false

            } else {
               tempImages.push(modalImage.cloneNode(true));
               createFavorites();
            }

         } else {
            
            if(!(tempImages[(tempImages.length-1)].src == modalImage.src)){
            let moreThanFiveFavs = document.createElement("p");
            moreThanFiveFavs.textContent = "You cannot have more than 5 favorites. Please delete one already selected.";

            modalWindow.appendChild(moreThanFiveFavs);
            }
         }

      }


   }



   function createFavorites() {

      if (tempImages.length == 1 && typeof favoritesTitle === 'undefined') {
         let favoritesTitle = document.createElement("h1");
         favoritesTitle.id = "favoritesTitle";
         favoritesTitle.textContent = "Favorites List"
         favoritesBox.appendChild(favoritesTitle);
         let images_div = document.createElement("div");
         images_div.id = "images_div";
         favoritesBox.appendChild(images_div);


         image_box(tempImages[0]);


      } else{

         image_box(tempImages[tempImages.length - 1])

      }


   }


   function image_box(image) {



      let image_box = document.createElement("div");

      images_div.appendChild(image_box);

      let figure_image = document.createElement("div");

      image_box.appendChild(figure_image);

      figure_image.appendChild(image);

      image_box.onclick = function () { deleteButton() };




      function deleteButton() {
         let deleteMessageCaption = document.createElement("div")
         deleteMessageCaption.classList.add("deleteMessage");
         let deleteMessage = document.createElement("p");
         deleteMessage.textContent = "Delete";
         deleteMessageCaption.appendChild(deleteMessage);
         image_box.appendChild(deleteMessageCaption);

         deleteMessageCaption.onclick = function () { deleteImage() };

         function deleteImage() {
            image_box.remove();
            for (let i = 0; i < tempImages.length; i++) {
               if (tempImages[i] == image) {
                  tempImages.splice(i, 1);
               }
            }

         }



      }

   }
}